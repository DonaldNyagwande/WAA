import React from "react";

function Comments(props){
    return(
        <div>
            <h1>props</h1>
        </div>
    )
}
export default Comments;